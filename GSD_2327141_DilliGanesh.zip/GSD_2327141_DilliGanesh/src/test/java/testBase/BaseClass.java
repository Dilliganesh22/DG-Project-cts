package testBase;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import pageObjects.Page3_GSD;
import utilities.ExcelUtility;

public class BaseClass {
	public static WebDriver driver;
	public Logger logger;
	public Properties p;
	public ExcelUtility excelUtil;
	
	@BeforeTest
	@Parameters({"os", "browser"})
	public static void setup(String os, String browser) {
		
		switch(browser.toLowerCase()) {
			case "chrome":
				ChromeOptions c_options = new ChromeOptions();
				c_options.addArguments("--force-device-scale-factor=0.9");
				driver = new ChromeDriver(c_options);
				break;
				
			case "edge":
				EdgeOptions e_options = new EdgeOptions();
				e_options.addArguments("--force-device-scale-factor=0.9");
				driver = new EdgeDriver(e_options);
				break;
		}
		
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	
	@BeforeClass
	public void LoggerInstance() throws IOException {
		//loading properties file
		
		FileReader file = new FileReader(".//src/test/resources/config.properties");
		p = new Properties();
		p.load(file);
		
		excelUtil = new ExcelUtility(".\\testData\\GSD.xlsx");
		
		logger = LogManager.getLogger(this.getClass());
	}
	
	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
	
	public String captureScreen(String tname) throws IOException{
		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
		
		String targetFilePath=System.getProperty("user.dir")+"\\screenshots\\Test_Failed\\" + tname + "_" + timeStamp + ".png";
		File targetFile=new File(targetFilePath);
		
		sourceFile.renameTo(targetFile);
			
		return targetFilePath;
	}
}
