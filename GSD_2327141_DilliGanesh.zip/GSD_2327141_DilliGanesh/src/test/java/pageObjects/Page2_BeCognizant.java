package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Page2_BeCognizant extends BasePage{ 
	
	public Page2_BeCognizant(WebDriver driver) {
		super(driver);
	}
	
	//WebElement
	@FindBy(xpath="//input[@id='oneC_searchAutoComplete']") 
	@CacheLookup private WebElement SearchBox;
	
	@FindBy(xpath="//div[@class='searchInputIcon']")
	@CacheLookup private WebElement searchLens;
	
	@FindBy(xpath="//div[@class='appsSearchResult']") 
	@CacheLookup private WebElement LiveSupportGSD;
	
	//Action methods 
		public void FindSearchBox(String input)
		{ 
			SearchBox.sendKeys(input);;
		} 
		public void ClickSearchIcon() {
			searchLens.click();
		} 
		
		public void clickLivesupport() {
			// TODO Auto-generated method stub
			LiveSupportGSD.click();
		}
		
		
}
