package pageObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Page1_CaptureUserInfo extends BasePage{ 
	
	public Page1_CaptureUserInfo(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	//WebElements 
	@FindBy(xpath="//button[@id='O365_MainLink_Me']") 
	@CacheLookup private WebElement AccountLogo; 
	
	
	@FindBy(xpath="//div[@id='mectrl_currentAccount_primary']") 
	@CacheLookup private WebElement UserName; 
	
	@FindBy(xpath="//div[@id='mectrl_currentAccount_secondary']")
	@CacheLookup private WebElement UserMailid; 
	
	@FindBy(xpath="//*[@aria-label='OneCognizant. Image: OneCognizant. ']")
	@CacheLookup private WebElement oneCognizant; 
	
	
	//Action methods 
	public void ClickAccountManager() throws InterruptedException
	{ 
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='O365_MainLink_Settings']")));
		Thread.sleep(10000);
		AccountLogo.click();	
	} 
	public WebElement getUsername() {
		return UserName;
		
	} 
	public WebElement getMailid() {
		return UserMailid;
	} 
	public WebElement ClickoneC() {
		return oneCognizant;
	}
	
	
}
