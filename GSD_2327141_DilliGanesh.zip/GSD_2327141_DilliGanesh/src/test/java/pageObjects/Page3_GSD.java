package pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class Page3_GSD extends BasePage{ 
	
	public Page3_GSD(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	
	@FindBy(xpath="//*[text()='Welcome to the all-in-one Live Support!']")
	@CacheLookup private WebElement WelcomeMsg;  
	
	//updated
	@FindBy(xpath="//a[@id='menu1']/span[@class='optionLangSelected']")
	@CacheLookup private WebElement defLanguage;  
	
	//updated
	@FindBy(xpath="//a[@id='menu2']/span[@class='optionCountrySelected']")
	@CacheLookup private WebElement defCountry; 
	
	
	@FindBy(xpath="//a[@id='menu1']")
	@CacheLookup private WebElement langugeDropDown; 
	
	//updated
	@FindBy(xpath="//ul[@class='dropdown-menu langList show']/li/a")
	@CacheLookup private List<WebElement> LanguageDropdownElements; 
	
	
	@FindBy(xpath="//a[@id='menu2']")
	@CacheLookup private WebElement countryDropDown;
	
	@FindBy(xpath="//ul[@class='dropdown-menu countryList pt-0 show']/li[@role='presentation']/a")
	@CacheLookup private List<WebElement> countryDropdownElements;
	
	//div[@data-toggle='tooltip']
	@FindBy(xpath="//div[@data-toggle='tooltip']")
	 private List<WebElement> tooltipElements;
	
	
	
	//action method
	public WebElement Validate_WelcomeMsg()
	{ 
		 return WelcomeMsg;
	} 
	public String Validate_deflang() {
		return defLanguage.getText();
	} 
	public String Validate_defcountry() {
		return defCountry.getText();
	}
	public void clickLanguageDropDown() {
		langugeDropDown.click();
	}
	public WebElement getLanguageDropDown() {
		return langugeDropDown;
	}
	public List<WebElement> getLanguageDropdownElements() {
		return LanguageDropdownElements;
	}
	public void clickCountryDropDown() {
		countryDropDown.click();
	}
	public List<WebElement> getCountryDropdownElements() {
		return countryDropdownElements;
	}
	public List<WebElement> getTooltipElements() {
		return tooltipElements;
	}
	
	
	
}