package testCases;

import java.lang.reflect.Array;
import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.Page1_CaptureUserInfo;
import pageObjects.Page2_BeCognizant;
import pageObjects.Page3_GSD;
import testBase.BaseClass;
import utilities.DataProviders;
import utilities.Screenshot;


public class TC_001_ValidateWelcomeMsg extends BaseClass{
	
	@Test(groups = "sanity", dataProvider="GSDInput",dataProviderClass=DataProviders.class)
	public void validateWelcomeMsg(String input) throws InterruptedException {
		
		logger.info("****** Starting TC_001_CaptureUserInfo ******");
		
		try {
			driver.get(p.getProperty("baseURL"));
			
			Page1_CaptureUserInfo page1 = new Page1_CaptureUserInfo(driver);
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
			
			page1.ClickAccountManager();
			logger.info("Clicked Profile Button");
			
			logger.info("Getting UserName and MailID");
			WebElement userName = wait.until(ExpectedConditions.visibilityOf(page1.getUsername()));
			WebElement MailId = wait.until(ExpectedConditions.visibilityOf(page1.getMailid()));
			System.out.println("**** User Info ****");
			System.out.println(userName.getText());
			System.out.println(MailId.getText());
			
			excelUtil.setCellData("User_Profile_Info", 1, 0, userName.getText());
			excelUtil.setCellData("User_Profile_Info", 1, 1, MailId.getText());
			logger.info("Setting values in the excel file success");
	
			
			WebElement OneCURL = wait.until(ExpectedConditions.elementToBeClickable(page1.ClickoneC())); 
			driver.navigate().to(OneCURL.getAttribute("href"));
			logger.info("Navigated to OneC Portal");
			
			Page2_BeCognizant page2 = new Page2_BeCognizant(driver);
			
			page2.FindSearchBox(input);
			logger.info("Entered GSD in the Search Bar");
			
			Thread.sleep(3000);
			
			page2.clickLivesupport();
			logger.info("Clicked Live Support GSD");
			
			Page3_GSD page3 = new Page3_GSD(driver);
			
			logger.info("Validating the Welcome Message of GSD Page");
			driver.switchTo().frame("appFrame");
			
			WebElement welcomeGSD = wait.until(ExpectedConditions.visibilityOf(page3.Validate_WelcomeMsg())) ;
			
			if(welcomeGSD.getText().equals("Welcome to the all-in-one Live Support!")) {
				Screenshot.takeScreenshot(driver, "TC_001_ValidateWelcomeMsg");
				logger.info("TC_001_CaptureUserInfo: Testcase Success");
				Assert.assertTrue(true);
			}
			else {
				logger.error("TC_001_CaptureUserInfo: Testcase Failed");
				Assert.fail();
			}
		
		}
		catch(Exception e) {
			System.out.println(e);
			logger.error("TC_001_CaptureUserInfo: Testcase Failed");
			Assert.fail();
		}
		
		logger.info("****** Finished TC_001_CaptureUserInfo ******");
	}
	


	
	
	
}
