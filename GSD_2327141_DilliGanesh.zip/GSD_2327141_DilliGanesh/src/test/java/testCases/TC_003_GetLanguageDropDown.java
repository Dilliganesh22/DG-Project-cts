package testCases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.Page3_GSD;
import testBase.BaseClass;
import utilities.Screenshot;

public class TC_003_GetLanguageDropDown extends BaseClass{
	
	@Test(dependsOnGroups = "sanity")
	public void getLanguageDropDownDetails() {
		logger.info("****** Starting TC_003_GetLanguageDropDown ******");
		try {
			Page3_GSD page3 = new Page3_GSD(driver);
			Thread.sleep(5000);
			
			page3.clickLanguageDropDown();
			logger.info("Language dropdown is clicked");
			
			logger.info("Taking Screenshot...");
			Screenshot.takeScreenshot(driver, "TC_003_GetLanguageDropDown");
			
			logger.info("Getting language dropdown elements");
			List<WebElement> lanDropDown = page3.getLanguageDropdownElements();
			
			logger.info("Setting values in the excel file success");
			System.out.println("**** Language Dropdown details ****");
			if(lanDropDown.size() > 0) {
				int row=1;
				for(WebElement element : lanDropDown) {
					System.out.println(element.getText());
					excelUtil.setCellData("List_Of_Languages", row++, 0, element.getText());
				}
				logger.info("TC_003_GetLanguageDropDown: TestCase Success");
				Assert.assertTrue(true);
			}
			else {
				logger.error("TC_003_GetLanguageDropDown: TestCase Failed");
				Assert.fail();
			}
			
		}
		catch(Exception e) {
			logger.error("TC_003_GetLanguageDropDown: TestCase Failed");
			Assert.fail();
		}
		logger.info("****** Finished TC_003_GetLanguageDropDown ******");
	}
}
