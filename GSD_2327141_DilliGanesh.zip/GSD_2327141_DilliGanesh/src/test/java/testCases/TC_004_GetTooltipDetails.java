package testCases;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.Page3_GSD;
import testBase.BaseClass;
import utilities.RandomNumGenerator;
import utilities.Screenshot;

public class TC_004_GetTooltipDetails extends BaseClass {
	
	@Test(dependsOnGroups = "sanity")
  public void getGsdDetailsWithTooltips() {
	  logger.info("****** Starting TC_004_GetTooltipDetails ******");
	  try {
		  Page3_GSD page3 = new Page3_GSD(driver);
		  WebElement currentElement;
		  
		  for(int i=0;i<3;i++) {
			  
			  page3.clickCountryDropDown();
			  logger.info("Country Dropdown is clicked");
			  
			  logger.info("Getting country dropdown elements");
			  List<WebElement> cntryElements = page3.getCountryDropdownElements();
			  
			  int randomIndex = RandomNumGenerator.getRandomNumber(0, cntryElements.size());
			  currentElement = cntryElements.get(randomIndex);
			  
			  String currentCountry = currentElement.getText();
			  currentElement.click();
			  logger.info(currentCountry + " is clicked");
			  
			  List<WebElement> currentTooltipElements = page3.getTooltipElements();
			  
			  if(currentTooltipElements.size() > 0) {
				  logger.info("Taking Screenshot...");
				  Screenshot.takeScreenshot(driver, "TC_004_GetTooltipDetails_" + currentCountry);
				  
				  logger.info("Setting values in the excel for " + currentCountry);
				  excelUtil.setToolTipCells("Tooltips_Details",currentCountry,currentTooltipElements );
				  
				  for(WebElement tooltipele : currentTooltipElements) {
					  if(!tooltipele.getAttribute("data-bs-original-title").equals("")) {
						  System.out.println(tooltipele.getAttribute("data-bs-original-title") + " - " + tooltipele.getText());
					  }  
				  }
				  
			  }
			  else {
				  logger.error("TC_004_GetTooltipDetails: TestCase Failed");
				  Assert.fail();
			  }  	  
		  }
		  logger.info("TC_004_GetTooltipDetails: TestCase Success");
		  Assert.assertTrue(true);  
	  }
	  catch(Exception e) {
		  logger.error("TC_004_GetTooltipDetails: TestCase Failed");
		  System.out.println(e);
		  Assert.fail();
	  }
	  logger.info("****** Finished TC_004_GetTooltipDetails ******");
  }
}
