package testCases;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.Page1_CaptureUserInfo;
import pageObjects.Page2_BeCognizant;
import pageObjects.Page3_GSD;
import testBase.BaseClass;
import utilities.DataProviders;
import utilities.Screenshot;

public class TC_002_DefaultCountry_Lang extends BaseClass{
	
	@Test(dependsOnGroups = "sanity", dataProvider="LangCountry", dataProviderClass=DataProviders.class)
	public void ValidateCountryLang(String d_language, String d_country) {
		logger.info("****** Starting TC_002_DefaultCountry_Lang ******");
		try {
			Thread.sleep(5000);
			Page3_GSD page3 = new Page3_GSD(driver);
			
			String d_Lang = page3.Validate_deflang();
			String d_Cntry = page3.Validate_defcountry();
			logger.info("Getting default language and country from application");
			
			if(d_Lang.equals(d_language) && d_Cntry.equals(d_country)) {
				logger.info("Taking Screenshot....");
				Screenshot.takeScreenshot(driver, "TC_002_DefaultCountry");
				Assert.assertTrue(true);
				logger.info("TC_002_DefaultCountry_Lang: TestCase Success");
			}
			else {
				Assert.fail();
				logger.info("TC_002_DefaultCountry_Lang: TestCase Failed");
			}
			
		}
		catch(Exception e) {
			logger.error("TC_002_DefaultCountry_Lang: TestCase Failed");
			Assert.fail();
		}
		logger.info("****** Finished TC_002_DefaultCountry_Lang ******");
	}
}
