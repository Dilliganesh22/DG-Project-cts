package utilities;

import java.io.IOException;

import org.testng.annotations.DataProvider;

public class DataProviders {

	//DataProvider 1
	
	@DataProvider(name="GSDInput")
	public String [][] getData() throws IOException
	{
		String path=".\\testData\\GSD.xlsx";//taking xl file from testData
		
		ExcelUtility xlutil=new ExcelUtility(path);//creating an object for XLUtility
		
		int totalrows=xlutil.getRowCount("Inputs");	
		int totalcols=xlutil.getCellCount("Inputs",1);
				
		String input[][]=new String[totalrows][totalcols];//created for two dimension array which can store the data user and password
		
		for(int i=1;i<=totalrows;i++)  //1   //read the data from xl storing in two deminsional array
		{		
			for(int j=0;j<totalcols;j++)  //0    i is rows j is col
			{
				input[i-1][j]= xlutil.getCellData("Inputs",i, j);  //1,0
			}
		}
	return input;//returning two dimension array
				
	}
	
	//DataProvider 2
	
	@DataProvider(name="LangCountry")
	public String [][] getDefaultData() throws IOException
	{
		String path=".\\testData\\GSD.xlsx";//taking xl file from testData
		
		ExcelUtility xlutil=new ExcelUtility(path);//creating an object for XLUtility
		
		int totalrows=xlutil.getRowCount("Default_Country_Language");	
		int totalcols=xlutil.getCellCount("Default_Country_Language",1);
				
		String d_values[][]=new String[totalrows][totalcols];//created for two dimension array which can store the data user and password
		
		for(int i=1;i<=totalrows;i++)  //1   //read the data from xl storing in two deminsional array
		{		
			for(int j=0;j<totalcols;j++)  //0    i is rows j is col
			{
				d_values[i-1][j]= xlutil.getCellData("Default_Country_Language",i, j);  //1,0
			}
		}
	return d_values;//returning two dimension array
				
	}
	
	//DataProvider 3
	
	//DataProvider 4
}
