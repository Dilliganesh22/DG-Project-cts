package utilities;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Screenshot {
	public static void takeScreenshot(WebDriver driver, String fileName) {
		
		File scrnShot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    File shareshot= new File(".\\screenshots\\Test_Success\\" + fileName + ".png");
	     //png----portable network graphics 
	    try {
			FileUtils.copyFile(scrnShot, shareshot);
			System.out.println(fileName + " screenshot saved successfully.");
		} catch (IOException e) {
			System.out.println("Unable to take Screenshot: " + fileName);
		}
	    
	}

}
