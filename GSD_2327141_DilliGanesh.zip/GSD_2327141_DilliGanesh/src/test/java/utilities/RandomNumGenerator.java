package utilities;
import java.util.concurrent.ThreadLocalRandom;

public class RandomNumGenerator {
	public static int getRandomNumber(int startIndex, int endIndex) {
		return ThreadLocalRandom.current().nextInt(startIndex, endIndex);
	}
}
