Detailed Description:    
====================

Navigate to Be. Cognizant Website and capture the user information.
Click One Cognizant application.
Search GSD in One Cognizant and click on Live Support - GSD application from search results.
Validate the welcome message of GSD Application.
Validate the default country and language.
Get all the drop-down details from Language drop down.
Get all the details present in the GSD page with tooltips and by changing Location from drop down (for three random Locations).

Key Automation Scope:
====================
Handling alert, different browser windows, search option.
Navigating back to home page.
Extract multiple options items & store in collections.
Capture warning message.
Data Driven approach.
Cross Browser Testing.

Output: [Chrome and Edge]
==================

**** User Info ****
Ganesh, Dilli (Contractor)
2327141@cognizant.com
TC_001_ValidateWelcomeMsg screenshot saved successfully.
TC_002_DefaultCountry screenshot saved successfully.
TC_003_GetLanguageDropDown screenshot saved successfully.
**** Language Dropdown details ****
English
Portuguese
TC_004_GetTooltipDetails_Poland screenshot saved successfully.
Issues related to Cognizant machine and its operating system - Operating System/Hardware
Cognizant VPN solutions provide highly secure remote access and increase flexibility and cost savings - Cognizant VPN
Queries related to Cognizant network (LAN /WiFi) / Firewall / Client & Cognizant connectivity / Network Diagram / Vnet / Data Card - Network Services
Queries related to IT Asset Management System and its software - Software and Asset management
This app will be used to send and receive emails / messages for internal and external communications through microsoft teams / outlook - Email and Messaging
It is the centralized management utility that helps to manage virtual machines and allows an administrator to manage and monitor storages - Server and Storage
Queries related to Cognizant user account / password reset / distribution list / common mailbox / service account - Account Management
Managers: Search & Discover right talent for your requirements through self-service - Talent Market Place
Payroll app for India associates to view / update various payroll related transactions - Payroll
My Career app is the unified resource for role and skill mapping of an associate under the Cognizant Career Architecture - MyCareer
PeopleSoft HCM - a core SOR for all Cognizant Associates/CWRs, processes and functions workflows/automation - PeopleSoft HCM
App for India associates to manage Time in Office. - TruTime
Basic app for infra related queries raised by new-joiners during their initial days at Cognizant - Newcomer @ Cognizant
Peoplesoft Enterprise Service Automation system. - Peoplesoft ESA
Application helps Corporate Security to improve security awareness among associates by rolling out assessment. - Security Endorsement Tool
App for HR, compensation & organizational letters - e-Letters
One stop solution for associates to avail daily workplace transportation services - One Transport
A platform for enrollment of dependents for Group medical insurance, and enroll for Medical claims - Medi Assist
This App is used for raising a new ID Card request for reasons like Info change, Faded/Damaged, Lost and Transfer - ID Card App
Accessibility Concierge Service - Accessibility Concierge Service
Learning platform that helps you stay future-ready - Academy Support
Queries related to visa request initiation, visa stamping, post processing, visa maxout, and visa documet process - Global Mobility
App for India domestic travel requests and expense claims. It also facilitates International business travel and relocations. - Travel and Expense
Global Environment Health and Safety - Global Environment Health and Safety
TC_004_GetTooltipDetails_Europe screenshot saved successfully.
Issues related to Cognizant machine and its operating system - Operating System/Hardware
Cognizant VPN solutions provide highly secure remote access and increase flexibility and cost savings - Cognizant VPN
Queries related to Cognizant network (LAN /WiFi) / Firewall / Client & Cognizant connectivity / Network Diagram / Vnet / Data Card - Network Services
Queries related to IT Asset Management System and its software - Software and Asset management
This app will be used to send and receive emails / messages for internal and external communications through microsoft teams / outlook - Email and Messaging
It is the centralized management utility that helps to manage virtual machines and allows an administrator to manage and monitor storages - Server and Storage
Queries related to Cognizant user account / password reset / distribution list / common mailbox / service account - Account Management
Managers: Search & Discover right talent for your requirements through self-service - Talent Market Place
Payroll app for India associates to view / update various payroll related transactions - Payroll
My Career app is the unified resource for role and skill mapping of an associate under the Cognizant Career Architecture - MyCareer
PeopleSoft HCM - a core SOR for all Cognizant Associates/CWRs, processes and functions workflows/automation - PeopleSoft HCM
App for India associates to manage Time in Office. - TruTime
Basic app for infra related queries raised by new-joiners during their initial days at Cognizant - Newcomer @ Cognizant
Peoplesoft Enterprise Service Automation system. - Peoplesoft ESA
Application helps Corporate Security to improve security awareness among associates by rolling out assessment. - Security Endorsement Tool
App for HR, compensation & organizational letters - e-Letters
One stop solution for associates to avail daily workplace transportation services - One Transport
A platform for enrollment of dependents for Group medical insurance, and enroll for Medical claims - Medi Assist
This App is used for raising a new ID Card request for reasons like Info change, Faded/Damaged, Lost and Transfer - ID Card App
Accessibility Concierge Service - Accessibility Concierge Service
Learning platform that helps you stay future-ready - Academy Support
Queries related to visa request initiation, visa stamping, post processing, visa maxout, and visa documet process - Global Mobility
App for India domestic travel requests and expense claims. It also facilitates International business travel and relocations. - Travel and Expense
TC_004_GetTooltipDetails_Luxembourg screenshot saved successfully.
Issues related to Cognizant machine and its operating system - Operating System/Hardware
Cognizant VPN solutions provide highly secure remote access and increase flexibility and cost savings - Cognizant VPN
Queries related to Cognizant network (LAN /WiFi) / Firewall / Client & Cognizant connectivity / Network Diagram / Vnet / Data Card - Network Services
Queries related to IT Asset Management System and its software - Software and Asset management
This app will be used to send and receive emails / messages for internal and external communications through microsoft teams / outlook - Email and Messaging
It is the centralized management utility that helps to manage virtual machines and allows an administrator to manage and monitor storages - Server and Storage
Queries related to Cognizant user account / password reset / distribution list / common mailbox / service account - Account Management
Managers: Search & Discover right talent for your requirements through self-service - Talent Market Place
Payroll app for India associates to view / update various payroll related transactions - Payroll
My Career app is the unified resource for role and skill mapping of an associate under the Cognizant Career Architecture - MyCareer
PeopleSoft HCM - a core SOR for all Cognizant Associates/CWRs, processes and functions workflows/automation - PeopleSoft HCM
App for India associates to manage Time in Office. - TruTime
Basic app for infra related queries raised by new-joiners during their initial days at Cognizant - Newcomer @ Cognizant
Peoplesoft Enterprise Service Automation system. - Peoplesoft ESA
Application helps Corporate Security to improve security awareness among associates by rolling out assessment. - Security Endorsement Tool
App for HR, compensation & organizational letters - e-Letters
One stop solution for associates to avail daily workplace transportation services - One Transport
A platform for enrollment of dependents for Group medical insurance, and enroll for Medical claims - Medi Assist
This App is used for raising a new ID Card request for reasons like Info change, Faded/Damaged, Lost and Transfer - ID Card App
Accessibility Concierge Service - Accessibility Concierge Service
Learning platform that helps you stay future-ready - Academy Support
Queries related to visa request initiation, visa stamping, post processing, visa maxout, and visa documet process - Global Mobility
App for India domestic travel requests and expense claims. It also facilitates International business travel and relocations. - Travel and Expense

===============================================
Suite
Total tests run: 4, Passes: 4, Failures: 0, Skips: 0
===============================================


Jar Files:
==========


  <project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>
  <groupId>CAS_GSD</groupId>
  <artifactId>CAS_GSD</artifactId>
  <version>0.0.1-SNAPSHOT</version>
    <build> 
	  <plugins> 
		  <plugin> 
			  <groupId>org.apache.maven.plugins</groupId> 
			  <artifactId>maven-compiler-plugin</artifactId> 
			  <version>3.8.1</version> 
			  <configuration> 
				  <source>1.8</source> 
				  <target>1.8</target> 
			  </configuration> 
		  </plugin> 
		  <plugin> 
			  <groupId>org.apache.maven.plugins</groupId> 
			  <artifactId>maven-surefire-plugin</artifactId> 
			  <version>3.0.0-M1</version> 
			  <configuration> 
				  <suiteXmlFiles> 
				  	<suiteXmlFile>testng.xml</suiteXmlFile> 
				  </suiteXmlFiles> 
			  </configuration> 
		  </plugin> 
	  </plugins> 
  </build>
  <dependencies>
  	
	<dependency>
	    <groupId>org.seleniumhq.selenium</groupId>
	    <artifactId>selenium-java</artifactId>
	    <version>4.18.1</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.testng/testng -->
	<dependency>
	    <groupId>org.testng</groupId>
	    <artifactId>testng</artifactId>
	    <version>7.9.0</version>
	    <scope>test</scope>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.apache.poi/poi -->
	<dependency>
	    <groupId>org.apache.poi</groupId>
	    <artifactId>poi</artifactId>
	    <version>5.2.5</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.apache.poi/poi-ooxml -->
	<dependency>
	    <groupId>org.apache.poi</groupId>
	    <artifactId>poi-ooxml</artifactId>
	    <version>5.2.5</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-core -->
	<dependency>
	    <groupId>org.apache.logging.log4j</groupId>
	    <artifactId>log4j-core</artifactId>
	    <version>2.23.1</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/com.aventstack/extentreports -->
	<dependency>
	    <groupId>com.aventstack</groupId>
	    <artifactId>extentreports</artifactId>
	    <version>5.1.1</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.apache.commons/commons-lang3 -->
	<dependency>
	    <groupId>org.apache.commons</groupId>
	    <artifactId>commons-lang3</artifactId>
	    <version>3.14.0</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.apache.logging.log4j/log4j-api -->
	<dependency>
	    <groupId>org.apache.logging.log4j</groupId>
	    <artifactId>log4j-api</artifactId>
	    <version>2.23.1</version>
	</dependency>

  </dependencies>
</project>
